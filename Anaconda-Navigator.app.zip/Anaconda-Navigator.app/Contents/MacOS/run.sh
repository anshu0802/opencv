#!/bin/sh
source "/Users/anshurathour/anaconda3"/bin/activate root
"/Users/anshurathour/anaconda3"/bin/anaconda-navigator $@
